
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>About Us</title>
    <link rel="stylesheet" href="phpstyle.css">

    
</head>
<body background="images/images (2).jpg">
     
     <div class="aboutpage">
        <img  class="img2"  src="images/people scholorships.jpg">
    <h1 class="about1"><marquee>About Us! <br>Please read the below information</marquee></h1>
    <p class="para1">Hello People of World We have Copmany by the name Online Scholorship and you can online register your self with a litle bit money and after your registeration you will recieve an Email from our Company IT Gropup. Our company has 8 years experience and our company team and esepcially our IT Manger Eng'Farhad Yarmal is now in this company (Online Scholoship Company) they always publish info about Scholorship in lots of Websites and this website is the main website of International Scholoships you register your self and choose your coutry of scholorship like which country you prefer after you registered yourself you will get an Email from our company our company Boss Is <spam> Baryalai Khan Noorzai.</spam> for contact and more information please click <a href="http://localhost/Contact%20Us/">Contact Us </a> Button.</p>

    </div>
    <a class="link1" href="http://localhost/international%20Scholorships/">Home Page</a>
    
</body>
</html>