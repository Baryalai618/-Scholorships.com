
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Contact Us</title>
    <link rel="stylesheet" href="phpstyle.css">

    
</head>
<body>
    
    <h1 class="contact1"><marquee>Contact Us!</marquee></h1>
    <h2 class="contact2">Our phone numbers for Calling...</h2>
    <h4 class="contact3">( +93749749227 ) (+93705230842 )</h4>
    <p class="contact4">For more information about our company please click on of the below icons and follow our company IT group  and we will aware you from our company policies.<br>Our instagram page is for publishing the Scolorships,Our Feacebook icon is also for publishing Scholorships and our Watsapp icon is for getting information about the scholoships.</p>
 
     
   <a class="link1" href="http://localhost/international%20Scholorships/">Home Page</a>
   
   <a  href="https://facebook.com/Baryalai Noorzai  ">
       <img class="logo" src="img.php/facebook.png">
   </a>
   <a  href="https://instagram.com/Baryalai Noorzai  ">
       <img class="logo" src="img.php/instagram.png">
   </a>
   <a href="https://Wattsapp.com/Baryalai Noorzai  ">
       <img class="logo" src="img.php/logo.png">
   </a>
    
</body>
</html>