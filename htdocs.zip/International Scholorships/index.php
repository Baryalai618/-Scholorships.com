
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Inernational Scholorships</title>
    <link rel="stylesheet" href="phpstyle.css">

    
</head>
<body>

    <img class="img1"  src="images/important.jpg">
    <img class="img1" src="images/images 3.jpg">
    <img class="img1" src="images/images 4.png">
  
   <a class="tag1" href="http://localhost/register/">Register</a>&nbsp &nbsp &nbsp
   <a class="tag1" href="http://localhost/about%20Us/">About Us </a>&nbsp &nbsp &nbsp
   <a class="tag1" href="http://localhost/Contact%20Us/">Contact Us </a>&nbsp &nbsp &nbsp
   <a class="tag1" href="http://localhost/profile/">Profile</a>
 
  <h1 class="title1"> <marquee>Hi!Welcome Everyone in Online Scholorship Site</marquee></h1>
   <div class="card">
     
   </div>
 
  <h2 class="title2"><marquee>International <spam>Scholorships</spam></marquee></h2>
       <p class="parahome"> Hello Everyone in this website you can register yourself and get Scholorship<br> of your favorite 
        Countries and please rgister your self click the register button<br> and chosse your favorite scholorship
         of countries when your registeration complited<br> we will send you Email.</p>



 <img src="images/images 4.png">
<img src="images/images (1).jpg">
 <img src="images/images (2).jpg">
 <img src="images/images 3.jpg">
 <img src="images/important.jpg">
 <img src="images/people scholorships.jpg">
      
     
    
</body>
</html>