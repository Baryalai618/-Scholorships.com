
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Company Profile</title>
    <link rel="stylesheet" href="phpstyle.css">

    
</head>
<body>
    <h1 class="profile1">Baryalai Noorzai</h1>

    <img class="img3" src="images/photo.jpg">

  <a class="link1" href="http://localhost/international%20Scholorships/">Home Page</a>

<img src="images/important.jpg">
<img src="images/people scholorships.jpg">
<img src="images/images (2).jpg">
   <img src="images/images 4.png">
<img src="images/images (1).jpg">

 <img src="images/images 3.jpg">
 
    
</body>
</html>